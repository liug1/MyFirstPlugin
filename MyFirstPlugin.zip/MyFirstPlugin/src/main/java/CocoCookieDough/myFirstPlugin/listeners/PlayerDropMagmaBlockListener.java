package CocoCookieDough.myFirstPlugin.listeners;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Item;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

public class PlayerDropMagmaBlockListener implements Listener {

    private final JavaPlugin plugin;

    // Max time to wait for the item to settle on the ground (ticks). 60 = 3 seconds.
    private static final int MAX_TICKS_TO_WAIT = 60;

    public PlayerDropMagmaBlockListener(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerDropMagmaBlock(PlayerDropItemEvent event) {
        final Item dropped = event.getItemDrop();

        if (dropped.getItemStack().getType() != Material.MAGMA_BLOCK) return;

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (!dropped.isValid() || dropped.isDead()) {
                    cancel();
                    return;
                }

                if (ticks++ >= MAX_TICKS_TO_WAIT) {
                    cancel();
                    return;
                }

                if (!dropped.isOnGround()) return;

                if (!dropped.getLocation().getChunk().isLoaded()) {
                    cancel();
                    return;
                }

                Block below = dropped.getLocation().getBlock().getRelative(BlockFace.DOWN);

                if (below.getType() == Material.WET_SPONGE) {
                    below.setType(Material.SPONGE);
                    dropped.remove(); // consume magma block
                }

                cancel();
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }
}
