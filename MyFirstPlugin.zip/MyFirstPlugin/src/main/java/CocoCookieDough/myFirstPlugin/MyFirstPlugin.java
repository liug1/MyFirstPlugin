package CocoCookieDough.myFirstPlugin;

import CocoCookieDough.myFirstPlugin.listeners.PlayerDropMagmaBlockListener;
import org.bukkit.plugin.java.JavaPlugin;

public final class MyFirstPlugin extends JavaPlugin {

    @Override
    public void onEnable() {
        getServer().getPluginManager().registerEvents(new PlayerDropMagmaBlockListener(this), this);
        getLogger().info("MyFirstPlugin enabled.");
    }

    @Override
    public void onDisable() {
        getLogger().info("MyFirstPlugin disabled.");
    }
}
